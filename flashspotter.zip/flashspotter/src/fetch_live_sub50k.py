#!/usr/bin/env python3
"""
fetch_live_sub50k.py
Hits the public Uniswap-v2 subgraph and writes every pair with
reserveUSD < 50 000 into tiny_liq.csv (overwrites the placeholder file).
No keys, no login, 2-second run.
"""
import requests, csv, sys, time

URL = "https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v2"
QUERY = """
{ pairs(first: 1000, where: {reserveUSD_lt: "50000"}, orderBy: reserveUSD, orderDirection: asc) {
    id
    reserveUSD
} }
"""

def main():
    print("Grabbing live sub-50k pairs from the Uniswap-v2 subgraph …")
    rsp = requests.post(URL, json={"query": QUERY}, timeout=30)
    rsp.raise_for_status()
    pairs = rsp.json()["data"]["pairs"]
    if not pairs:
        print("No pairs returned – graph timeout?")
        sys.exit(1)
    with open("src/tiny_liq.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["pair"])
        for p in pairs:
            w.writerow([p["id"]])
    print(f"Written {len(pairs)} live pairs to src/tiny_liq.csv – ready for scanner.")

if __name__ == "__main__":
    main()
